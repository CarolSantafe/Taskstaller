package model;

public enum Status {
    COMPLETE, INCOMPLETE
}
